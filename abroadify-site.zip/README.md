# Abroadify (MVP)

A simple React + Vite + Tailwind site you can deploy on Netlify.

## Quick start (local)
1) Install Node.js LTS (https://nodejs.org)
2) In a terminal:
   ```bash
   npm install
   npm run dev
   ```
   Visit the printed URL.

## Deploy to Netlify
- Push this folder to a new GitHub repo.
- In Netlify: "Add new site" → "Import from GitHub".
- Build command: `npm run build`
- Publish directory: `dist`

## Custom domain
- In Netlify settings, add a custom domain (e.g., abroadify.com).