import React, { useState } from 'react'

export default function AbroadifyLanding() {
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const features = [
    { title: 'City Micro-Guides', desc: '$3 per city or all-access library. Offline PDFs for zero-Wi‑Fi days.' },
    { title: 'Student-to-Student Q&A', desc: 'Real answers from students who were just there—what actually works.' },
    { title: 'Budget & Safety', desc: 'Metro vs rideshare, discount spots, typical closing times, safety checklists.' },
    { title: 'Pins that Matter', desc: 'Exact coordinates for photo spots + restaurants students truly loved.' },
  ]

  const cities = [
    { name: 'Valencia', country: 'Spain', tag: 'Pilot', blurb: 'Your Spring 2026 test city' },
    { name: 'Florence', country: 'Italy', tag: 'Coming soon', blurb: 'Arts, gelato, and day trips' },
    { name: 'London', country: 'UK', tag: 'Coming soon', blurb: 'Museums, markets, theatre' },
  ]

  function handleSubmit(e) {
    e.preventDefault()
    if (email.trim()) setSubmitted(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-white via-slate-50 to-white text-slate-800">
      <header className="sticky top-0 z-30 backdrop-blur bg-white/70 border-b border-slate-200/60">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-xl bg-slate-900 text-white grid place-items-center font-bold">A</div>
            <span className="font-semibold">Abroadify</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#features" className="hover:text-slate-900">Features</a>
            <a href="#cities" className="hover:text-slate-900">Cities</a>
            <a href="#pricing" className="hover:text-slate-900">Pricing</a>
            <a href="#faq" className="hover:text-slate-900">FAQ</a>
          </nav>
          <a href="#cta" className="text-sm font-medium px-3 py-1.5 rounded-xl bg-slate-900 text-white hover:opacity-90">Join the pilot</a>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-4 pt-14 pb-10 grid md:grid-cols-2 gap-8 items-center">
        <div>
          <p className="inline-block text-xs tracking-wide uppercase font-semibold text-slate-500 bg-slate-100 px-2 py-1 rounded-lg">Built by an FSUIP alum</p>
          <h1 className="mt-4 text-4xl md:text-5xl font-extrabold leading-tight">
            The student-built toolkit for <span className="underline decoration-slate-300">studying abroad in Europe</span>
          </h1>
          <p className="mt-4 text-slate-600 text-lg">
            Micro‑guides, exact pins, budgeting & safety checklists, and student‑to‑student answers — starting with FSU Valencia.
          </p>

          <div id="cta" className="mt-6">
            {submitted ? (
              <div className="rounded-2xl border border-emerald-300 bg-emerald-50 p-4 text-emerald-900">
                Thanks! You’re on the list for the Spring 2026 pilot. We’ll email you when the beta opens.
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="FSU email"
                  className="flex-1 rounded-xl border border-slate-300 px-4 py-3 focus:outline-none focus:ring-2 focus:ring-slate-400"
                />
                <button type="submit" className="rounded-xl px-5 py-3 bg-slate-900 text-white font-semibold hover:opacity-90">
                  Get early access
                </button>
              </form>
            )}
            <p className="mt-2 text-xs text-slate-500">No spam. Opt out anytime.</p>
          </div>
        </div>

        <div className="relative">
          <div className="rounded-3xl border bg-white shadow-sm p-4 grid gap-3">
            <div className="rounded-2xl bg-slate-900 text-white p-4">
              <div className="text-xs opacity-80">Sample Micro‑Guide</div>
              <div className="mt-1 font-semibold">Valencia Weekend Kit</div>
              <ul className="mt-3 text-sm space-y-2 opacity-95 list-disc ml-5">
                <li>Metro vs. rideshare: <span className="font-semibold">Metro wins</span> to beach & city center</li>
                <li>Don’t miss: Horchata in El Carmen, City of Arts & Sciences, Turia bike trail</li>
                <li>Words to learn: por favor, gracias, ¿cuánto cuesta?, tarjeta, aseos</li>
                <li>Pic spot pins: Torres de Serranos, Plaza de la Virgen, L’Umbracle</li>
              </ul>
            </div>
            <div className="rounded-2xl border p-4">
              <div className="font-semibold">Budget & Safety</div>
              <ul className="mt-2 text-sm list-disc ml-5 text-slate-600">
                <li>Daily budget: €35–€55 (meals, transit, museum)</li>
                <li>Typical closing: shops 20:00, big markets 15:00 Sun closed</li>
                <li>Keep passport + AirTag in a dedicated spot</li>
              </ul>
            </div>
            <div className="rounded-2xl border p-4">
              <div className="font-semibold">Hacks</div>
              <ul className="mt-2 text-sm list-disc ml-5 text-slate-600">
                <li>Search flights in incognito + flexible dates</li>
                <li>TooGoodToGo for bakery deals after 18:00</li>
                <li>Journal on the flight home — capture 5 highlights</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-2xl md:text-3xl font-bold">What students get</h2>
        <div className="mt-6 grid md:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border p-5 hover:shadow-sm transition">
              <div className="font-semibold">{f.title}</div>
              <p className="mt-2 text-sm text-slate-600">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="cities" className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-2xl md:text-3xl font-bold">Launch cities</h2>
        <div className="mt-6 grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {cities.map((c) => (
            <div key={c.name} className="rounded-2xl border p-5">
              <div className="flex items-center justify-between">
                <div className="text-lg font-semibold">{c.name}, {c.country}</div>
                <span className="text-xs px-2 py-1 rounded-full bg-slate-100 text-slate-600">{c.tag}</span>
              </div>
              <p className="mt-2 text-sm text-slate-600">{c.blurb}</p>
              <ul className="mt-4 text-sm text-slate-600 list-disc ml-5">
                <li>Must‑eat foods</li>
                <li>Neighborhoods to stay</li>
                <li>Exact photo pins</li>
                <li>Transit + budgeting</li>
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-2xl md:text-3xl font-bold">Simple pricing</h2>
        <div className="mt-6 grid md:grid-cols-2 gap-4">
          <div className="rounded-2xl border p-6">
            <div className="text-sm font-semibold text-slate-500">Per City</div>
            <div className="mt-1 text-3xl font-extrabold">$3</div>
            <p className="mt-2 text-sm text-slate-600">Own one micro‑guide forever. Great for weekend trips.</p>
            <button className="mt-4 rounded-xl px-5 py-3 bg-slate-900 text-white font-semibold hover:opacity-90 w-full">Buy a city</button>
          </div>
          <div className="rounded-2xl border p-6 bg-slate-50">
            <div className="text-sm font-semibold text-slate-500">All‑Access</div>
            <div className="mt-1 text-3xl font-extrabold">$60</div>
            <p className="mt-2 text-sm text-slate-600">Full library + offline downloads + Q&A access.</p>
            <button className="mt-4 rounded-xl px-5 py-3 bg-slate-900 text-white font-semibold hover:opacity-90 w-full">Get all cities</button>
          </div>
        </div>
      </section>

      <section id="faq" className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-2xl md:text-3xl font-bold">FAQ</h2>
        <div className="mt-6 grid gap-4">
          <FaqItem q="Is this official FSU content?" a="Abroadify is student‑built and complements FSUIP; we’ll pilot with FSU Valencia to gather feedback." />
          <FaqItem q="Is there an app?" a="We’re starting on the web with offline PDFs; native apps are planned if students want them." />
          <FaqItem q="Can I contribute tips or pins?" a="Yes! Students can submit Q&A answers, photo coordinates, and restaurant pins." />
        </div>
      </section>

      <footer className="border-t border-slate-200/70 py-10 mt-8">
        <div className="mx-auto max-w-6xl px-4 text-sm text-slate-500 flex flex-col md:flex-row items-center justify-between gap-4">
          <div>© {new Date().getFullYear()} Abroadify • Made for students, by students</div>
          <div className="flex gap-4">
            <a href="#" className="hover:text-slate-900">Contact</a>
            <a href="#" className="hover:text-slate-900">Privacy</a>
            <a href="#" className="hover:text-slate-900">Terms</a>
          </div>
        </div>
      </footer>
    </div>
  )
}

function FaqItem({ q, a }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="rounded-2xl border p-4">
      <button onClick={() => setOpen(!open)} className="w-full text-left font-semibold flex items-center justify-between">
        <span>{q}</span>
        <span className={`transition-transform ${open ? "rotate-45" : ""}`}>+</span>
      </button>
      {open && <p className="mt-3 text-sm text-slate-600">{a}</p>}
    </div>
  )
}